# GDC Transportes — Android / Capacitor

Projeto Android preparado para transformar o painel GDC Transportes em APK.

## Identidade
- Nome: GDC Transportes
- App ID: com.gdc.transportes
- Plataforma: Android
- Tecnologia: Capacitor

## Gerar o projeto Android
1. Instale Node.js.
2. Entre nesta pasta.
3. Execute:
   npm install
   npx cap add android
   npx cap sync android
4. Abra no Android Studio:
   npx cap open android
5. No Android Studio, escolha Build > Build APK(s).

## Ícone e splash
Os arquivos `resources/icon.png` e `resources/splash.png` já estão incluídos.
Para gerar todos os tamanhos nativos, use:
   npx capacitor-assets generate

## Observação
Esta entrega prepara a estrutura Android e a identidade visual. O login/banco de dados real deve apontar para o backend da GDC Transportes antes da distribuição para vários usuários.
